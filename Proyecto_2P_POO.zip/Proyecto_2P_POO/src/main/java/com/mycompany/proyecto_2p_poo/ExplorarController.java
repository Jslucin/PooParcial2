/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_2p_poo;

import com.mycompany.proyecto_2p_poo.rovers.Constantes;
import com.mycompany.proyecto_2p_poo.rovers.Crateres;
import com.mycompany.proyecto_2p_poo.rovers.Rover;
import com.mycompany.proyecto_2p_poo.rovers.RoversEnergiaEolica;
import com.mycompany.proyecto_2p_poo.rovers.RoversEnergiaSolar;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * FXML Controller class
 *
 * @author samu_
 */
public class ExplorarController implements Initializable {

    @FXML
    private ComboBox<Rover> comborovers;
    @FXML
    private TextField textfi;
    @FXML
    private TextArea Zonacomandos;
    @FXML
    private Pane panel;
    private  List<Rover> rovers;
    List<Crateres> craters;
    @FXML
    private Pane paneldatos;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try{
            craters=Crateres.obtenerCrateres();
            for(Crateres i: craters){
                Circle c= null;
                if (verificarCrater(i)){
                     c= new Circle(i.getRadio()/2,Color.RED);
                     c.setStroke(Color.RED);
                }else{
                    c= new Circle(i.getRadio()/2,Color.TRANSPARENT);
                    c.setStroke(Color.RED);
                }
                StackPane st= new StackPane();
                st.getChildren().addAll(c);
                panel.getChildren().addAll(st);
                st.setLayoutX(i.getCoordsx()/2);
                st.setLayoutY(i.getCoordsy()/2);
                st.setOnMouseClicked((MouseEvent ev)->{
                    paneldatos.getChildren().clear();
                    ev.consume();
                    Label datoscra=new Label();
                    datoscra.setText("  Crater: "+i.getNombre()+"\n  Radio: "+i.getRadio()+"\n  PosicionX: " +i.getCoordsx()+"\n  PosicionY: "+i.getCoordsy());
                    paneldatos.getChildren().add(datoscra);
                });
               
            }
            rovers=Rover.obtenerRovers();
            comborovers.getItems().addAll(rovers);
                
        }catch (IOException ex){
            System.out.print("Error en el sistema");
        }
        
   
    }
    

    @FXML
    private void cargaracciones(ActionEvent event) {
        for(Rover i: rovers){
            if (i.getImg()!=null){
                panel.getChildren().remove(i.getImg());
            }
        }
        Rover roveractual=comborovers.getValue();
        try{
            Image image=new Image(App.class.getResource("rover.png").openStream(),30,30,true,true);
            ImageView imgvw= new ImageView(image);
            roveractual.setImg(imgvw);
            panel.getChildren().add(imgvw);
            imgvw.setLayoutX(roveractual.getUbicacionx());
            imgvw.setLayoutY(roveractual.getUbicaciony());
            
        }catch (IOException ex){
            System.out.print("Error en el sistema");
            
        }
        
    }
    public void Actualizaarchivo(Rover roveractual) throws IOException{
        BufferedWriter bf= new BufferedWriter(new FileWriter(Constantes.ARCHIVOS+"/rovers-1.txt",false));
        String linea;
        for (Rover t: rovers){
            if(t.getNombre().equals(roveractual.getNombre())){
                if(t instanceof RoversEnergiaSolar){
                    linea=t.getNombre()+","+String.valueOf(roveractual.getUbicaciony())+","+String.valueOf(roveractual.getUbicacionx())+",solar"+","+String.valueOf(roveractual.getGrados());
                }
                else{
                    linea=t.getNombre()+","+String.valueOf(roveractual.getUbicaciony())+","+String.valueOf(roveractual.getUbicacionx())+",eolica,"+String.valueOf(roveractual.getGrados());
                }
            }
            else{
                if(t instanceof RoversEnergiaSolar){
                    linea=t.getNombre()+","+String.valueOf(t.getUbicaciony())+","+String.valueOf(t.getUbicacionx())+",solar,"+String.valueOf(t.getGrados());
                }
                else{
                    linea=t.getNombre()+","+String.valueOf(t.getUbicaciony())+","+String.valueOf(t.getUbicacionx())+",eolica,"+String.valueOf(t.getGrados());
                }
                        
            }
            bf.write(linea);
            bf.newLine();
            bf.flush();//para que se escriba inmediatamente en el archi
        }
        bf.close();
    }
    public void Actualizarcomandos(String accion){
        String textobase=Zonacomandos.getText();
        String linea;
        if (textobase!=null){
            linea=accion+"\n"+textobase;
            
        }else{
            linea=accion;
        }
        Zonacomandos.setText(linea);
    }
    public boolean verificarCrater(Crateres crater) throws IOException{
        BufferedReader bf= new BufferedReader(new FileReader(Constantes.ARCHIVOS+"/minerales.txt"));
        String linea;
        boolean salida=false;
        while((linea=bf.readLine())!=null){
            String[] partes= linea.split(";");
            if(partes[0].equals(crater.getNombre())){
                salida=true;
            }
        }
        return salida;
        
    }
    public String[] obtenerListavieja(Crateres craters,LocalDate date) throws IOException{
         String[] entregar= {};
         DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
         String fecha = date.format(formatter);
         BufferedReader bf= new BufferedReader(new FileReader(Constantes.ARCHIVOS+"/minerales.txt"));
         String linea;
         while((linea=bf.readLine()) != null){
             
             String partes[]= linea.split(";");
             if(partes[0].equals(craters.getNombre())& partes[1].equals(fecha)){
                if (partes.length==2){
                    partes[2]="e";
                }

                if (!partes[2].equals("e")){
                    if(partes[2].contains(",")){
                    entregar=partes[2].split(",");
                   }else{
                     entregar[0]=partes[2];
                   }

                }
             
            }
         }
         bf.close();
        return entregar;
    }
    public String[] combinarlistas(String[] viejas, String[] nuevas){
        String[] combinado={};
        if (viejas.length>0 & nuevas.length>0){
            combinado=viejas;
            for(int i=0; i<nuevas.length; i++){
                int h=0;
                for(int t=0; t<viejas.length;t++){
                    if (nuevas[i].equals(viejas[t])){
                        h=1;
                    }
                }
                if(h==0){
                    combinado[combinado.length]=nuevas[i];
                }
            }
        }
        else if(viejas.length==0 & nuevas.length>0){
            combinado=nuevas;
        }
        else if(viejas.length>0 & nuevas.length==0){
            combinado=viejas;
        }
        return combinado;
    }
    @FXML
    private void Iniciarcomandos(KeyEvent event) {
        if (event.getCode() == event.getCode().ENTER) {
            try{
                Rover roveractual=comborovers.getValue();
                if(roveractual!= null){
                String accion= textfi.getText();
                textfi.clear();
                
                if(accion.toLowerCase().equals("avanzar")){
                    
                    roveractual.avanzar();
                    Actualizaarchivo(roveractual);
                    Actualizarcomandos(accion);
                }
                
                if(accion.contains(":")){
                    String[] partes=accion.split(":");
                    if (partes[0].toLowerCase().equals("girar")){
                        try{
                            roveractual.girar(Double.parseDouble(partes[1]));
                            Actualizaarchivo(roveractual);
                            Actualizarcomandos(accion);
                        }catch(NumberFormatException ex){
                            Alert alerta1=new Alert(Alert.AlertType.ERROR);
                            alerta1.setContentText("No es un número");
                            alerta1.show();
                        }
                    }else if(partes[0].toLowerCase().equals("dirigirse")){
                        if(partes[1].contains(",")){
                            String[] coords=partes[1].split(",");
                            try{
                                roveractual.dirigirse(Double.parseDouble(coords[0]), Double.parseDouble(coords[1]));
                                Actualizaarchivo(roveractual);
                                Actualizarcomandos(accion);
                            }catch(NumberFormatException ex){
                                Alert alerta2=new Alert(Alert.AlertType.ERROR);
                                alerta2.setContentText("No es un número");
                                alerta2.show();     
                            }
                        }
                    }else if(!(partes[0].toLowerCase().equals("dirigirse")) & !(partes[0].toLowerCase().equals("dirigirse"))){
                        Alert alerta3=new Alert(Alert.AlertType.ERROR);
                        alerta3.setContentText("No es un comando");
                        alerta3.show();
                    }
                    
                }
                    if(accion.toLowerCase().equals("sensar")){
                        
                        for(Crateres l: craters){
                            BufferedWriter bf2= new BufferedWriter(new FileWriter(Constantes.ARCHIVOS + "/minerales.txt",false));
                            Circle circulo=new Circle(l.getCoordsx()/2,l.getCoordsy()/2,l.getRadio()/2);
                            if(circulo.intersects(roveractual.getUbicacionx(), roveractual.getUbicaciony(),30,30)){
                                String lineanueva="";
                                String lineaaentregar="";
                                LocalDate date = LocalDate.now();
                                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                                String fecha = date.format(formatter);
                                String minerales= roveractual.sensar();
                                BufferedReader bf3= new BufferedReader(new FileReader(Constantes.ARCHIVOS+"/minerales.txt"));
                                String linea;
                                if(verificarCrater(l)){
                                    
                                    while((linea=bf3.readLine())!= null){
                                        lineaaentregar=linea;
                                        String[] partes=linea.split(";") ;
                                        if (partes[0].equals(l.getNombre()) &partes[1].equals(fecha)){
                                            String[] nuevos={};
                                            System.out.println("Minerales: "+minerales);
                                            if (minerales.contains(",")){
                                                nuevos= minerales.split(",");
                                            }else if(!minerales.equals("")){
                                                nuevos[0]=minerales;
                                        }else{
                                            nuevos[0]="e";
                                        }
                                            String[] viejos={};
                                            if (partes.length==2){
                                                partes[2]="e";
                                            }

                                            if (!partes[2].equals("e")){
                                                if(partes[2].contains(",")){
                                                    viejos=partes[2].split(",");
                                                }else{
                                                    viejos[0]=partes[2];
                                                }
                                            }
                                        
                                        String[] combinable=viejos;
                                        if(!nuevos[0].equals("e")){
                                            combinable= combinarlistas(viejos,nuevos);
                                        }
                                        lineanueva=combinable[0];
                                        if(combinable.length>1){
                                            for(int i=1; i<combinable.length; i++){
                                                lineanueva=lineanueva+","+combinable[i];
                                            }
                                        }
                                            lineaaentregar=partes[0]+";"+partes[1]+";"+ lineanueva;
                                        }
                                        System.out.println("i"+lineaaentregar);
                                        bf2.write(lineaaentregar);
                                        bf2.newLine();
                                        bf2.flush();
                                        Circle c;
                                        c= new Circle(l.getRadio()/2,Color.RED);
                                        c.setStroke(Color.RED);
                                        StackPane st= new StackPane();
                                        st.getChildren().addAll(c);
                                        panel.getChildren().addAll(st);
                                        st.setLayoutX(l.getCoordsx()/2);
                                        st.setLayoutY(l.getCoordsy()/2);
                                    }
                                
                                }else{
                                    String lineaescribir=l.getNombre()+";"+fecha+";"+minerales;
                                    BufferedWriter bf4= new BufferedWriter(new FileWriter(Constantes.ARCHIVOS + "/minerales.txt",true));
                                    bf4.write(lineaescribir);
                                    bf4.newLine();
                                    bf4.flush();
                                    bf3.close();
                                    Circle c;
                                    c= new Circle(l.getRadio()/2,Color.RED);
                                    c.setStroke(Color.RED);
                                    StackPane st= new StackPane();
                                    st.getChildren().addAll(c);
                                    panel.getChildren().addAll(st);
                                    st.setLayoutX(l.getCoordsx()/2);
                                    st.setLayoutY(l.getCoordsy()/2);
                                }
                                
                               
                                  
                                
                                
                                
                            }
                            bf2.close();
                        }   


                        Actualizarcomandos("sensar");
                    }
                    if(accion.toLowerCase().equals("cargar")){
                        roveractual.cargar();
                        Actualizaarchivo(roveractual);
                        Actualizarcomandos(accion);
                    }
                    if(!(accion.toLowerCase().equals("cargar")) & !(accion.toLowerCase().equals("avanzar")) & !(accion.contains(":")) & !(accion.toLowerCase().equals("sensar")) ){
                        Alert alerta1= new Alert(Alert.AlertType.ERROR);
                        alerta1.setContentText("El comando no existe");
                        alerta1.show();
                        textfi.clear();
                    }
                    
                }else{
                    Alert alerta1= new Alert(Alert.AlertType.ERROR);
                    alerta1.setContentText("No se escogio rover");
                    alerta1.show();
                }   
            }catch(IOException ex){
                System.out.print("Error en el sistema");
            }
            
        }
        
    }
    }