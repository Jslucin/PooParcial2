/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_2p_poo;

import com.mycompany.proyecto_2p_poo.rovers.Crateres;
import com.mycompany.proyecto_2p_poo.rovers.Rover;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;

/**
 * FXML Controller class
 *
 * @author samu_
 */
public class PlanificarrutasController implements Initializable {

    @FXML
    private TextField crtbuscar;
    @FXML
    private GridPane Lista;
    private List<Crateres> craters;
    @FXML
    private ComboBox<Rover> roverplan;
    private List<Rover> rovers;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            rovers=Rover.obtenerRovers();
            roverplan.getItems().addAll(rovers);
        
        
    }    

    @FXML
    private void generarrutas(KeyEvent event) {
        Rover roveru= roverplan.getValue();
        
        try{
            craters=Crateres.obtenerCrateres();
        }catch (IOException ex){
            System.out.println("Error en el sistema");
        }
            
        
        if (event.getCode() == event.getCode().ENTER) {
            if(roveru!=null){
            String obtenido=crtbuscar.getText();
            crtbuscar.clear();
            if(obtenido.contains(",")){
                String[] partes=obtenido.split(",");
                
                List<Crateres> buscar= new ArrayList<>();
                int longi=partes.length;
                
                for(int i=0; i<longi;i++){
                    for (Crateres l: craters){
                        if(partes[i].equals(l.getNombre())){
                            buscar.add(l);
                        }
                    }
                    
                }
                List <Crateres> orden= new ArrayList<>();
                int posa=0;
                while(!buscar.isEmpty()){
                    int l=0;
                    List<Double> desplazamientos= new ArrayList<>();
                    for (Crateres i: buscar){
                        double x= Math.pow(i.getCoordsx()-roveru.getUbicacionx(),2);
                        double y= Math.pow(i.getCoordsy()-roveru.getUbicaciony(),2);
                        double desplazamiento= Math.sqrt(x+y);
                        desplazamientos.add(l,desplazamiento);
                        l++;
                        
                    }
                    double valormin=10000;
                    int posmin=0;
                    int lugarpos=0;
                    for (Double d: desplazamientos){
                        if (d<valormin){
                            valormin=d;
                            posmin=lugarpos;
                        }
                        lugarpos++;   
                        
                    }
                    orden.add(posa,buscar.get(posmin));
                    roveru.setUbicacionx(buscar.get(posmin).getCoordsx());
                    roveru.setUbicaciony(buscar.get(posmin).getCoordsy());
                    buscar.remove(posmin);
                    posa=posa+1;
                }
                int i=0;
                for(Crateres L: orden){
                    Lista.addRow(i, new Label(L.getNombre()));
                    i++;
                }
                Lista.setVisible(true);
                
                
                    
            }
            }else{
            Alert alerta1= new Alert(Alert.AlertType.ERROR);
            alerta1.setContentText("No se escogio rover");
            alerta1.show();
        }
        
        }   
    }
    
}
